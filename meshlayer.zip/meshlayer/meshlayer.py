# -*- coding: utf-8 -*-

from OpenGL.GL import *
from OpenGL.GL import shaders

from PyQt4.QtOpenGL import QGLPixelBuffer, QGLFormat

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *

from pyspatialite import dbapi2 as sqlite

import numpy
from math import pow, log, ceil

import os
import re
import time
import traceback

from gl_mesh import GlMesh, ColorLegend
from utilities import unitConversionFactor, linemerge

class MeshLayerType(QgsPluginLayerType):
    def __init__(self):
        QgsPluginLayerType.__init__(self, MeshLayer.LAYER_TYPE)

    def createLayer(self):
        return MeshLayer(None)

    def showLayerProperties(self, layer):
        layer.showImageDialog()
        # indicate that we have shown the properties dialog
        return True

class SpatialiteMeshDataProvider(QgsDataProvider):

    dataChanged = pyqtSignal()
    unitsChanged = pyqtSignal(str)
    sourceUnits = {"concentration" : u"kg/m³",
                   "norme_vitesse_darcy" : "m/s",
                   "potentiel" : "m"}

    def __init__(self, uri, resultColumnName=None):
        super(QgsDataProvider, self).__init__(uri)
        self.uri = QgsDataSourceURI(uri)
        assert self.uri.database()
        conn = sqlite.connect(str(self.uri.database()))
        cur = conn.cursor()
        cur.execute("SELECT date FROM dates_simulation ORDER BY ID")
        self.__dates = []
        for [date] in cur.fetchall():
            self.__dates.append(date)
        self.__didx = 0

        self.__nodeValues = None
        self.__resultColumn = None
        self.__units = None
        self.setResultColumn(resultColumnName)
        self.__unitConvertionFactor = 1.

    def setUnits(self, units):
        self.__units = units
        sourceUnits = SpatialiteMeshDataProvider.sourceUnits[self.resultColumn()]
        if units != sourceUnits:
            if re.match(r'Bq', units):
                # get the specific activity in Bq/kg
                conn = sqlite.connect(str(self.uri.database()))
                cur = conn.cursor()
                cur.execute("""SELECT DISTINCT activite_specifique
                    FROM produits AS pdt INNER JOIN points_injection AS pti
                    ON pdt.ID = pti.pid""")
                specificActivity = cur.fetchone()[0]
                assert not cur.fetchone() # only one product for a simulation
                self.__unitConvertionFactor = \
                        unitConversionFactor(sourceUnits, units, specificActivity)
            else:
                self.__unitConvertionFactor = unitConversionFactor(sourceUnits, units)
        else:
            self.__unitConvertionFactor = 1.
        self.unitsChanged.emit(units)
        self.dataChanged.emit()

    def units(self):
        return self.__units

    def setResultColumn(self, columnName):
        # load results since it's the bottleneck for rendering
        reloadNeeded = columnName and self.__resultColumn != columnName
        self.__resultColumn = columnName
        if reloadNeeded:
            self.__nodeValues = []
            conn = sqlite.connect(str(self.uri.database()))
            cur = conn.cursor()
            for didx in range(len(self.__dates)):
                cur.execute("SELECT "+columnName+" "\
                        "FROM resultats_nodaux_sat "
                        "WHERE did = "+str(didx+1)+" "
                        "ORDER BY nid"
                        )
                self.__nodeValues.append(numpy.require(cur.fetchall(), numpy.float32))
            if not self.__nodeValues:
                raise RuntimeError("No result found")
            self.setUnits(SpatialiteMeshDataProvider.sourceUnits[columnName])

    def resultColumn(self):
        return self.__resultColumn

    def dates(self):
        return self.__dates

    def name(self):
        return 'spatialite_mesh'

    def crs(self):
        return QgsCoordinateReferenceSystem("epsg:27572")

    def description(self):
        return "mesh data provider for thyrsis sqlite backend"

    def extent(self): 
        conn = sqlite.connect(str(self.uri.database()))
        cur = conn.cursor()
        cur.execute("""SELECT 
            MIN(X(GEOMETRY)), MIN(Y(GEOMETRY)), MAX(X(GEOMETRY)), MAX(Y(GEOMETRY)) 
            FROM noeuds""")
        [xmin, ymin, xmax, ymax] = cur.fetchone()
        return QgsRectangle(xmin, ymin, xmax, ymax)

    def isValid(self):
        return True

    def nodeCoord(self):
        conn = sqlite.connect(str(self.uri.database()))
        cur = conn.cursor()
        cur.execute("SELECT X(GEOMETRY), Y(GEOMETRY), 0 FROM noeuds ORDER BY OGC_FID")
        return numpy.require(cur.fetchall(), numpy.float32, 'F')

    def triangles(self):
        """return a list of triangles described by node indices"""
        conn = sqlite.connect(str(self.uri.database()))
        cur = conn.cursor()
        cur.execute("""
            SELECT a, b, c FROM mailles WHERE d IS NULL
            UNION ALL
            SELECT a, b, c FROM mailles WHERE d IS NOT NULL
            UNION ALL
            SELECT a, c, d FROM mailles WHERE d IS NOT NULL""")
        idx = numpy.require(cur.fetchall(), numpy.int32, 'F')
        idx -= 1
        return idx

    def setDate(self, didx):
        assert didx < len(self.__dates)
        assert not self.__nodeValues or didx < len(self.__nodeValues)
        self.__didx = didx
        self.dataChanged.emit()

    def date(self):
        return self.__didx

    def nodeValues(self):
        """return values at nodes"""
        if not self.__nodeValues:
            return []
        else:
            return self.__unitConvertionFactor*self.__nodeValues[self.__didx]

    def maxValue(self, index=None):
        if not self.__nodeValues:
            return float('NaN')
        if index:
            return self.__unitConvertionFactor * numpy.max(self.__nodeValues[index])
        else:
            return self.__unitConvertionFactor * max([max_ for max_ in \
                    [numpy.max(values) for values in self.__nodeValues]])

    def dataSourceUri(self):
        return self.uri.uri()

    def readXml(self, node):
        element = node.toElement()
        self.setResultColumn(element.attribute("resultColumn"))
        self.setUnits(element.attribute("units"))
        self.setDate(int(element.attribute("dateIndex")))
        return True

    def writeXml(self, node, doc):
        element = node.toElement()
        element.setAttribute("units", self.units())
        element.setAttribute("resultColumn", self.resultColumn())
        element.setAttribute("dateIndex", self.date())
        return True

    def nodeAttributes(self, columnName):
        "return a numeric attribute value array for nodes"
        conn = sqlite.connect(str(self.uri.database()))
        cur = conn.cursor()
        cur.execute("SELECT "+columnName+" FROM noeuds ORDER BY OGC_FID")
        return numpy.require(cur.fetchall(), numpy.float32, 'F')

        

class MeshLayerLegendNode(QgsLayerTreeModelLegendNode):
    def __init__(self, nodeLayer, parent, legend):
        QgsLayerTreeModelLegendNode.__init__(self, nodeLayer, parent)
        self.text = ""
        self.image = legend.image()

    def data(self, role):
        if role == Qt.DisplayRole or role == Qt.EditRole:
            return self.text
        elif role  == Qt.DecorationRole:
            return self.image
        else:
            return None
    
    def draw(self, settings, ctx):
        im = QgsLayerTreeModelLegendNode.ItemMetrics()
        im.symbolSize = QSizeF(self.image.width(), self.image.height()) 
        im.labeSize =  QSizeF(0,0)
        if ctx:
            ctx.painter.drawImage(0, 0, self.image)
        return im

class MeshLayerLegend(QgsDefaultPluginLayerLegend):
    def __init__(self, layer, legend):
        QgsDefaultPluginLayerLegend.__init__(self, layer)
        self.nodes = []
        self.__legend = legend

    def createLayerTreeModelLegendNodes(self, nodeLayer):
        node = MeshLayerLegendNode(nodeLayer, self, self.__legend)
        self.nodes = [node]
        return self.nodes

class MeshLayer(QgsPluginLayer):

    LAYER_TYPE="thyrsis"

    __drawException = pyqtSignal(str)

    def __raise(self, err):
        raise Exception(err)

    def __init__(self, uri=None, columnName=None):
        QgsPluginLayer.__init__(self, MeshLayer.LAYER_TYPE, "mesh_layer")
        if uri:
            self.__load(SpatialiteMeshDataProvider(uri, columnName))
        self.setValid(True)
        self.__drawException.connect(self.__raise)

    #def setColorLegend(self, legend):
    #    self.__legend = legend
    #    self.__glMesh.setLegend(self.__legend)
    #    self.__legend.symbologyChanged.connect(self.__symbologyChanged)

    def colorLegend(self):
        return self.__legend

    def __load(self, meshDataProvider):

        self.setCrs(meshDataProvider.crs())
        self.setExtent(meshDataProvider.extent())
        self.__meshDataProvider = meshDataProvider
        self.__meshDataProvider.dataChanged.connect(self.triggerRepaint)

        self.__legend = ColorLegend()
        self.__legend.setParent(self)
        self.__legend.symbologyChanged.connect(self.__symbologyChanged)
        self.__glMesh = GlMesh(
                meshDataProvider.nodeCoord(), 
                meshDataProvider.triangles(),
                self.__legend
                )

    def __symbologyChanged(self):
        self.__layerLegend = MeshLayerLegend(self, self.__legend)
        self.setLegend(self.__layerLegend)
        self.legendChanged.emit()
        self.triggerRepaint()

    def readXml(self, node):
        element = node.toElement()
        meshDataProvider = SpatialiteMeshDataProvider(element.attribute("uri"), element.attribute("columnName"))
        if not meshDataProvider.readXml(node.namedItem("meshDataProvider")):
            return False

        self.__load(meshDataProvider)

        if not self.__legend.readXml(node.namedItem("colorLegend")):
            return False
        return True

    def writeXml(self, node, doc):
        """write plugin layer type to project (essential to be read from project)"""
        element = node.toElement()
        element.setAttribute("type", "plugin")
        element.setAttribute("name", MeshLayer.LAYER_TYPE)
        element.setAttribute("uri", self.__meshDataProvider.dataSourceUri())
        element.setAttribute("columnName", self.__meshDataProvider.resultColumn())

        dataProvider = doc.createElement("meshDataProvider")
        if not self.__meshDataProvider.writeXml(dataProvider, doc):
            return False
        element.appendChild(dataProvider)
        
        colorLegend = doc.createElement("colorLegend")
        if not self.__legend.writeXml(colorLegend, doc):
            return False
        element.appendChild(colorLegend)
        return True

    def dataProvider(self):
        return self.__meshDataProvider

    def draw(self, rendererContext):
        """This function is called by the rendering thread. 
        GlMesh must be created in the main thread."""
        with open('log.txt','a') as f:
            f.write('drawing mesh layer\n')
        try:
            painter = rendererContext.painter()
            img = None
            ext = rendererContext.extent()
            img = self.__glMesh.image(
                    painter.window().size(),
                    (ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum()),
                    self.__meshDataProvider.nodeValues())
        
            painter.drawImage(painter.window(), img)
            return True
        except Exception as e:
            # since we are in a thread, we must re-raise the exception
            self.__drawException.emit(traceback.format_exc())

    def isovalues(self, values):
        """return a list of multilinestring, one for each value in values"""
        idx = self.__meshDataProvider.triangles()
        vtx = self.__meshDataProvider.nodeCoord()
        lines = []
        for value in values:
            lines.append([])
            val = self.__meshDataProvider.nodeValues() - float(value)
            # we filer triangles in which the value is negative on at least
            # one node and positive on at leat one node
            filtered = idx[numpy.logical_or(
                val[idx[:, 0]]*val[idx[:, 1]] <= 0, 
                val[idx[:, 0]]*val[idx[:, 2]] <= 0 
                ).reshape((-1,))]
            # create line segments
            for tri in filtered:
                line = []
                # the edges are sorted to avoid interpolation error
                for edge in [sorted([tri[0], tri[1]]), 
                             sorted([tri[1], tri[2]]), 
                             sorted([tri[2], tri[0]])]:
                    if val[edge[0]]*val[edge[1]] <= 0:
                        alpha = -val[edge[0]]/(val[edge[1]] - val[edge[0]])\
                                if val[edge[1]] != val[edge[0]]\
                                else None
                        if alpha: # the isoline crosses the edge
                            #print alpha
                            #print val[tri[0]], val[tri[1]], val[tri[2]]
                            #print val[edge[0]], val[edge[1]]
                            assert alpha >= 0 and alpha <= 1
                            line.append( (1-alpha)*vtx[edge[0]] + alpha*vtx[edge[1]])
                        else: # the edge is part of the isoline
                            line.append(vtx[edge[0]])
                            line.append(vtx[edge[1]])
                if numpy.any(line[0] != line[-1]):
                    lines[-1].append(line)
            lines[-1] = linemerge(lines[-1])
        return lines


if __name__ == "__main__":
    import sys

    #app = QgsApplication(sys.argv, False)
    QgsApplication.setPrefixPath('/usr/local', True)
    QgsApplication.initQgis()

    assert len(sys.argv) >= 5
    
    layer = MeshLayer('dbname='+sys.argv[1], sys.argv[2])
    layer.dataProvider().setDate(int(sys.argv[3]))
    start = time.time()
    values = [float(v) for v in sys.argv[4:]]
    lines = layer.isovalues(values)
    print "total time ", time.time() - start 
    isolines = QgsVectorLayer("MultiLineString?crs=epsg:27572&field=value:double", "isovalues", "memory")
    pr = isolines.dataProvider()
    features = []
    for i, mutilineline in enumerate(lines):
        features.append(QgsFeature())
        features[-1].setGeometry(QgsGeometry.fromMultiPolyline([[QgsPoint(point[0], point[1]) \
                for point in line] for line in mutilineline]))
        features[-1].setAttributes([values[i]])
    pr.addFeatures(features)

    QgsVectorFileWriter.writeAsVectorFormat(isolines, "isovalues.shp", "isovalues", None, "ESRI Shapefile")



